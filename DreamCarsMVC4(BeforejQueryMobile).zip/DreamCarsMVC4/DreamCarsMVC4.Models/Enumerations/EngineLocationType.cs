﻿namespace DreamCarsMVC4.Models.Enumerations {

    public enum EngineLocationType : byte {

        Front = 0,
        Mid = 10,
        Rear = 20
    }
}