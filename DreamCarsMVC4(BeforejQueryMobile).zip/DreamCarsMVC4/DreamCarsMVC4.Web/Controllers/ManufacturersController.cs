using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;
using DreamCarsMVC4.Data.Context;
using DreamCarsMVC4.Models;

namespace DreamCarsMVC4.Web.Controllers
{   
    public class ManufacturersController : Controller
    {
        private DataContext context = new DataContext();

        public ManufacturersController() {
            Database.SetInitializer(new DataContextInitializer());
        }

        //
        // GET: /Manufacturers/

        public ViewResult Index()
        {
            return View(context.Manufacturers.Include(manufacturer => manufacturer.Models).ToList());
        }

        //
        // GET: /Manufacturers/Details/5

        public ViewResult Details(long id)
        {
            Manufacturer manufacturer = context.Manufacturers.Single(x => x.ManufacturerId == id);
            return View(manufacturer);
        }

        //
        // GET: /Manufacturers/Create

        public ActionResult Create()
        {
            return View();
        } 

        //
        // POST: /Manufacturers/Create

        [HttpPost]
        public ActionResult Create(Manufacturer manufacturer)
        {
            if (ModelState.IsValid)
            {
                context.Manufacturers.Add(manufacturer);
                context.SaveChanges();
                return RedirectToAction("Index");  
            }

            return View(manufacturer);
        }
        
        //
        // GET: /Manufacturers/Edit/5
 
        public ActionResult Edit(long id)
        {
            Manufacturer manufacturer = context.Manufacturers.Single(x => x.ManufacturerId == id);
            return View(manufacturer);
        }

        //
        // POST: /Manufacturers/Edit/5

        [HttpPost]
        public ActionResult Edit(Manufacturer manufacturer)
        {
            if (ModelState.IsValid)
            {
                context.Entry(manufacturer).State = EntityState.Modified;
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(manufacturer);
        }

        //
        // GET: /Manufacturers/Delete/5
 
        public ActionResult Delete(long id)
        {
            Manufacturer manufacturer = context.Manufacturers.Single(x => x.ManufacturerId == id);
            return View(manufacturer);
        }

        //
        // POST: /Manufacturers/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(long id)
        {
            Manufacturer manufacturer = context.Manufacturers.Single(x => x.ManufacturerId == id);
            context.Manufacturers.Remove(manufacturer);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}