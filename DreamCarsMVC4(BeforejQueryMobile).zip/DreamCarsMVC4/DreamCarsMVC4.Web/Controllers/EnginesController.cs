using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;
using DreamCarsMVC4.Data.Context;
using DreamCarsMVC4.Models;

namespace DreamCarsMVC4.Web.Controllers
{   
    public class EnginesController : Controller
    {
        private readonly DataContext _context = new DataContext();

        //
        // GET: /Engines/

        public ViewResult Index()
        {
            return View(_context.Engines.Include(engine => engine.AvailableOn).ToList());
        }

        public ViewResult ByModel(long id) {
            return View(_context.Models.FirstOrDefault(x => x.ModelId == id));
        }

        //
        // GET: /Engines/Details/5

        public ViewResult Details(long id)
        {
            Engine engine = _context.Engines.Single(x => x.EngineId == id);
            return View(engine);
        }

        //
        // GET: /Engines/Create

        public ActionResult Create()
        {
            return View();
        } 

        //
        // POST: /Engines/Create

        [HttpPost]
        public ActionResult Create(Engine engine)
        {
            if (ModelState.IsValid)
            {
                _context.Engines.Add(engine);
                _context.SaveChanges();
                return RedirectToAction("Index");  
            }

            return View(engine);
        }
        
        //
        // GET: /Engines/Edit/5
 
        public ActionResult Edit(long id)
        {
            Engine engine = _context.Engines.Single(x => x.EngineId == id);
            return View(engine);
        }

        //
        // POST: /Engines/Edit/5

        [HttpPost]
        public ActionResult Edit(Engine engine)
        {
            if (ModelState.IsValid)
            {
                _context.Entry(engine).State = EntityState.Modified;
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(engine);
        }

        //
        // GET: /Engines/Delete/5
 
        public ActionResult Delete(long id)
        {
            Engine engine = _context.Engines.Single(x => x.EngineId == id);
            return View(engine);
        }

        //
        // POST: /Engines/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(long id)
        {
            Engine engine = _context.Engines.Single(x => x.EngineId == id);
            _context.Engines.Remove(engine);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}