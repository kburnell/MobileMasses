using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;
using DreamCarsMVC4.Data.Context;
using DreamCarsMVC4.Models;

namespace DreamCarsMVC4.Web.Controllers {

    public class ModelsController : Controller {

        private readonly DataContext _context = new DataContext();

        public ViewResult Index() {
            return View(_context.Models.Include(model => model.Manufacturer).Include(model => model.AvailableEngines).ToList());
        }

        public ViewResult ByManufacturer(long id) {
            IList<Model> models = _context.Models.Include(x => x.Manufacturer).Include(x => x.AvailableEngines).Where(x => x.ManufacturerId == id).ToList();
            ViewBag.Manufacturer = models.First().Manufacturer.Name;
            return View(models);
        }

        public ViewResult Details(long id) {
            Model model = _context.Models.Single(x => x.ModelId == id);
            return View(model);
        }

        public ActionResult Create() {
            ViewBag.PossibleManufacturers = _context.Manufacturers;
            return View();
        }

        [HttpPost]
        public ActionResult Create(Model model) {
            if (ModelState.IsValid) {
                _context.Models.Add(model);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.PossibleManufacturers = _context.Manufacturers;
            return View(model);
        }

        public ActionResult Edit(long id) {
            Model model = _context.Models.Single(x => x.ModelId == id);
            ViewBag.PossibleManufacturers = _context.Manufacturers;
            return View(model);
        }

        [HttpPost]
        public ActionResult Edit(Model model) {
            if (ModelState.IsValid) {
                _context.Entry(model).State = EntityState.Modified;
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.PossibleManufacturers = _context.Manufacturers;
            return View(model);
        }

        public ActionResult Delete(long id) {
            Model model = _context.Models.Single(x => x.ModelId == id);
            return View(model);
        }

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(long id) {
            Model model = _context.Models.Single(x => x.ModelId == id);
            _context.Models.Remove(model);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

    }
}